package cn.edu.hebtu.software.canteen;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderSelectActivity extends AppCompatActivity {

    private ListView listView;
    private Handler handler;
    private MyAdapter adapter;
    private List<Map<String,Object>> list = new ArrayList<>();
    private TextView selectAll;
    private TextView selectRunning;
    private TextView selectFinish;
    private TextView selectCancel;
    private Button btnShowCalender;
    private PopupWindow popupWindow;
    private DatePicker datePicker;
    private TextView tvRtn;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_select);

        listView = findViewById(R.id.lv);
        tvRtn = findViewById(R.id.tv_rtn);

        //返回
        tvRtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderSelectActivity.this,BackActivity.class);
                startActivity(intent);
            }
        });
        //显示日历
        btnShowCalender = findViewById(R.id.btn_calender);
        btnShowCalender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCaclender();
            }
        });

        Order order = new Order();
        order.execute();

        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what){
                    case 1:
                        list = (List)msg.obj;
                        adapter = new MyAdapter(list,
                                OrderSelectActivity.this,
                                R.layout.activity_order_select_content);
                        break;
                    case 2:
                        break;
                }
            }
        };
        listView.setAdapter(adapter);

        selectAll = findViewById(R.id.select_all);
        selectRunning = findViewById(R.id.select_running);
        selectFinish = findViewById(R.id.select_finish);
        selectCancel = findViewById(R.id.select_cancel);

        selectAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAll.setTextColor(Color.RED);
                selectRunning.setTextColor(Color.BLACK);
                selectFinish.setTextColor(Color.BLACK);
                selectCancel.setTextColor(Color.BLACK);
                selectAll.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
                selectRunning.getPaint().setFlags(0);
                selectFinish.getPaint().setFlags(0);
                selectCancel.getPaint().setFlags(0);
                adapter = new MyAdapter(getAll()
                        ,OrderSelectActivity.this
                        ,R.layout.activity_order_select_content);
                listView.setAdapter(adapter);
            }
        });
        selectRunning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectRunning.setTextColor(Color.RED);
                selectAll.setTextColor(Color.BLACK);
                selectFinish.setTextColor(Color.BLACK);
                selectCancel.setTextColor(Color.BLACK);
                selectRunning.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
                selectAll.getPaint().setFlags(0);
                selectFinish.getPaint().setFlags(0);
                selectCancel.getPaint().setFlags(0);
                adapter = new MyAdapter(getRunning()
                        ,OrderSelectActivity.this
                        ,R.layout.activity_order_select_content);
                listView.setAdapter(adapter);
            }
        });
        selectFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectFinish.setTextColor(Color.RED);
                selectRunning.setTextColor(Color.BLACK);
                selectAll.setTextColor(Color.BLACK);
                selectCancel.setTextColor(Color.BLACK);
                selectFinish.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
                selectRunning.getPaint().setFlags(0);
                selectAll.getPaint().setFlags(0);
                selectCancel.getPaint().setFlags(0);
                adapter = new MyAdapter(getFinish()
                        ,OrderSelectActivity.this
                        ,R.layout.activity_order_select_content);
                listView.setAdapter(adapter);
            }
        });
        selectCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectCancel.setTextColor(Color.RED);
                selectRunning.setTextColor(Color.BLACK);
                selectFinish.setTextColor(Color.BLACK);
                selectAll.setTextColor(Color.BLACK);
                selectCancel.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
                selectRunning.getPaint().setFlags(0);
                selectFinish.getPaint().setFlags(0);
                selectAll.getPaint().setFlags(0);
                adapter = new MyAdapter(getCancel()
                        ,OrderSelectActivity.this
                        ,R.layout.activity_order_select_content);
                listView.setAdapter(adapter);
            }
        });
    }

    public class MyAdapter extends BaseAdapter {
        private List<Map<String,Object>> list;
        private Context context;
        private int itemId;

        public MyAdapter(List<Map<String,Object>> list,Context context,int itemId){
            this.list = list;
            this.context = context;
            this.itemId = itemId;
        }
        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null){
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemId,null);
            }
            TextView textName = convertView.findViewById(R.id.tv_order_name);
            TextView textCount = convertView.findViewById(R.id.tv_order_date);
            TextView textPrice = convertView.findViewById(R.id.tv_order_price);
            textName.setText((String)list.get(position).get("name"));
            textCount.setText((String)list.get(position).get("date"));
            textPrice.setText((String)list.get(position).get("price"));
            return convertView;
        }
    }

    public class Order extends AsyncTask<Void,Void,List> {
        private List<Map<String,Object>> list;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            list = new ArrayList();
        }

        @Override
        protected List doInBackground(Void... voids) {
            String path = "";
            try {
                URL url = new URL(path);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("contentType","utf-8");

                InputStream in = conn.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                BufferedReader buffer = new BufferedReader(reader);
                String str = buffer.readLine();

                JSONArray array = new JSONArray(str);
                for(int i = 0;i<array.length();++i){
                    JSONObject json = array.getJSONObject(i);
                    Map<String,Object> map = new HashMap<>();
                    map.put("name",json.get("name"));
                    map.put("date",json.get("date"));
                    map.put("counts",json.get("counts"));
                    list.add(map);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return list;
        }

        @Override
        protected void onPostExecute(List list) {
            Message message = new Message();
            if(list != null){
                message.what = 1;
                message.obj = list;
            }else{
                message.what = 2;
            }
            handler.sendMessage(message);
        }
    }

    public List<Map<String,Object>> getAll(){
        if(!list.isEmpty()){
            list.clear();
        }
        Map<String,Object> map1 = new HashMap<>();
        map1.put("name","张三");
        map1.put("date","2019-03-02");
        map1.put("price","￥13.00");
        Map<String,Object> map2 = new HashMap<>();
        map2.put("name","李四");
        map2.put("date","2019-03-10");
        map2.put("price","￥11.00");
        Map<String,Object> map3 = new HashMap<>();
        map3.put("name","皮卡丘");
        map3.put("date","2019-03-12");
        map3.put("price","￥8.00");
        Map<String,Object> map4 = new HashMap<>();
        map4.put("name","蜘蛛侠");
        map4.put("date","2019-03-16");
        map4.put("price","￥12.00");
        Map<String,Object> map5 = new HashMap<>();
        map5.put("name","鸡蛋");
        map5.put("date","2019-03-18");
        map5.put("price","￥10.00");
        list.add(map1);
        list.add(map2);
        list.add(map3);
        list.add(map4);
        list.add(map5);
        return list;
    }

    public List<Map<String,Object>> getRunning(){
        if(!list.isEmpty()){
            list.clear();
        }
        Map<String,Object> map1 = new HashMap<>();
        map1.put("name","孙悟空");
        map1.put("date","2019-05-29");
        map1.put("price","￥13.00");
        Map<String,Object> map2 = new HashMap<>();
        map2.put("name","猪八戒");
        map2.put("date","2019-05-29");
        map2.put("price","￥11.00");
        Map<String,Object> map3 = new HashMap<>();
        map3.put("name","唐僧");
        map3.put("date","2019-05-29");
        map3.put("price","￥8.00");
        Map<String,Object> map4 = new HashMap<>();
        map4.put("name","沙和尚");
        map4.put("date","2019-05-29");
        map4.put("price","￥12.00");
        Map<String,Object> map5 = new HashMap<>();
        map5.put("name","白龙马");
        map5.put("date","2019-05-29");
        map5.put("price","￥10.00");
        list.add(map1);
        list.add(map2);
        list.add(map3);
        list.add(map4);
        list.add(map5);
        return list;
    }

    public List<Map<String,Object>> getFinish(){
        if(!list.isEmpty()){
            list.clear();
        }
        Map<String,Object> map1 = new HashMap<>();
        map1.put("name","张三");
        map1.put("date","2019-03-02");
        map1.put("price","￥13.00");
        Map<String,Object> map2 = new HashMap<>();
        map2.put("name","李四");
        map2.put("date","2019-03-10");
        map2.put("price","￥11.00");
        Map<String,Object> map3 = new HashMap<>();
        map3.put("name","皮卡丘");
        map3.put("date","2019-03-12");
        map3.put("price","￥8.00");
        Map<String,Object> map4 = new HashMap<>();
        map4.put("name","蜘蛛侠");
        map4.put("date","2019-03-16");
        map4.put("price","￥12.00");
        Map<String,Object> map5 = new HashMap<>();
        map5.put("name","鸡蛋");
        map5.put("date","2019-03-18");
        map5.put("price","￥10.00");
        list.add(map1);
        list.add(map2);
        list.add(map3);
        list.add(map4);
        list.add(map5);
        return list;
    }

    public List<Map<String,Object>> getCancel(){
        if(!list.isEmpty()){
            list.clear();
        }
        Map<String,Object> map1 = new HashMap<>();
        map1.put("name","贾宝玉");
        map1.put("date","2019-03-02");
        map1.put("price","￥13.00");
        Map<String,Object> map2 = new HashMap<>();
        map2.put("name","林黛玉");
        map2.put("date","2019-03-10");
        map2.put("price","￥11.00");
        Map<String,Object> map3 = new HashMap<>();
        map3.put("name","薛宝钗");
        map3.put("date","2019-03-12");
        map3.put("price","￥8.00");
        Map<String,Object> map4 = new HashMap<>();
        map4.put("name","王熙凤");
        map4.put("date","2019-03-16");
        map4.put("price","￥12.00");
        Map<String,Object> map5 = new HashMap<>();
        map5.put("name","刘姥姥");
        map5.put("date","2019-03-18");
        map5.put("price","￥10.00");
        list.add(map1);
        list.add(map2);
        list.add(map3);
        list.add(map4);
        list.add(map5);
        return list;
    }
    //显示日历
    public void showCaclender() {
        View view = View.inflate(this, R.layout.activity_back_popup_calendar, null);
        popupWindow = new PopupWindow(this);
        popupWindow.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        popupWindow.setHeight(1250);

        popupWindow.setAnimationStyle(R.style.anim_calender_topbar);

        popupWindow.setContentView(view);
        popupWindow.update();

        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int popupWidth = view.getMeasuredWidth();
        int popupHeight = view.getMeasuredWidth();
        int[] location = new int[2];
        btnShowCalender.getLocationOnScreen(location);

        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 1;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setAttributes(lp);
        //调小是往上,调大是往下
        popupWindow.showAtLocation(btnShowCalender,
                Gravity.NO_GRAVITY,
                (location[0] + btnShowCalender.getWidth() / 2) - popupWidth / 2,
                location[1] - popupHeight + 1845);

        datePicker = view.findViewById(R.id.date_picker);
        initData();
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                popupWindow.dismiss();
            }
        });
    }
    public void initData(){
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        datePicker.init(year, month, day, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Intent intent = new Intent();
                intent.setClass(OrderSelectActivity.this,BackOrderCalendarShowActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
