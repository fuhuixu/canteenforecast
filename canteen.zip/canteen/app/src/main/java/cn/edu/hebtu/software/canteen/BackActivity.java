package cn.edu.hebtu.software.canteen;

import android.app.TabActivity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class BackActivity extends TabActivity implements ViewPager.OnPageChangeListener, View.OnTouchListener {
    //创建一个列表保存选项卡视图
    private List<View> viewList = new ArrayList<>();
    private String[] tabHostTag = {"tab1","tab2","tab3","tab4"};
    private int[] tabHostIconNormal = {R.drawable.back1,R.drawable.back2,R.drawable.back3,R.drawable.back4};
    private int[] tabHostIconSelect = {R.drawable.q9,R.drawable.q9,R.drawable.q9,R.drawable.q9};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_back);

        //食堂详情
        //跳转地图
        TextView tvCanteen1 = findViewById(R.id.tv_canteen1);
        tvCanteen1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackActivity.this,BaiduMapActivity.class);
                startActivity(intent);
            }
        });
        //查看食堂详情
        TextView tvCanteen2 = findViewById(R.id.tv_canteen2);
        tvCanteen2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackActivity.this,EstablishActivity.class);
                startActivity(intent);
            }
        });
        //商品推送跳转
        TextView tvPush = findViewById(R.id.tv_push);
        tvPush.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackActivity.this,PushActivity.class);
                startActivity(intent);
            }
        });
        ImageView ivPush = findViewById(R.id.iv_push);
        ivPush.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackActivity.this,PushActivity.class);
                startActivity(intent);
            }
        });
        //评价跳转
        ImageView ivEvalute = findViewById(R.id.iv_evaluate) ;
        ivEvalute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackActivity.this,BackEvaluateActivity.class);
                startActivity(intent);
            }
        });
        TextView tvEvalute = findViewById(R.id.tv_evalute);
        tvEvalute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackActivity.this,BackEvaluateActivity.class);
                startActivity(intent);
            }
        });
        //投票跳转
        ImageView ivToupiao = findViewById(R.id.iv_tp);
        ivToupiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackActivity.this,BackResultActivity.class);
                startActivity(intent);
            }
        });
        TextView tvToupiao = findViewById(R.id.tv_tp);
        tvToupiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackActivity.this,BackResultActivity.class);
                startActivity(intent);
            }
        });

        //1.获取tabhost控件
        final TabHost tabHost = findViewById(android.R.id.tabhost);
        //2.对tabhost进行初始化
        tabHost.setup();
        tabHost.setup(this.getLocalActivityManager());
        //3.添加选项卡
        //第一个选项卡
        tabHost.addTab(tabHost.newTabSpec(tabHostTag[0])
                .setIndicator(getTabView("首页",tabHostIconNormal[0]))
                .setContent(R.id.tab1));
        //第二个选项卡,//链式调用
        tabHost.addTab(tabHost.newTabSpec(tabHostTag[1])
                .setIndicator(getTabView("订单处理",tabHostIconNormal[1]))
                .setContent(new Intent(this,OrderManagerActivity.class)));
        //第三个选项卡
        tabHost.addTab(tabHost.newTabSpec(tabHostTag[2])
                .setIndicator(getTabView("订单查询",tabHostIconNormal[2]))
                .setContent(new Intent(this,OrderSelectActivity.class)));
        //第四个选项卡
        tabHost.addTab(tabHost.newTabSpec(tabHostTag[3])
                .setIndicator(getTabView("设置",tabHostIconNormal[3]))
                .setContent(new Intent(this,BackMineActivity.class)));

        setTabHostIcon((tabHost.getCurrentTabTag()));
        //给tabHost添加事件监听器
        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                setTabHostIcon(tabId);
                }
            });
        }

    //选项卡
   private void setTabHostIcon(String tabId){
        ImageView imageView1 = viewList.get(0).findViewById(R.id.iv_img);
        ImageView imageView2 = viewList.get(1).findViewById(R.id.iv_img);
        ImageView imageView3 = viewList.get(2).findViewById(R.id.iv_img);
        ImageView imageView4 = viewList.get(3).findViewById(R.id.iv_img);
        imageView1.setImageResource(R.drawable.back1);
        imageView2.setImageResource(R.drawable.back2);
        imageView3.setImageResource(R.drawable.back3);
        imageView4.setImageResource(R.drawable.back4);

        if(tabId.equals(tabHostTag[0])) {
            ImageView imageView = viewList.get(0).findViewById(R.id.iv_img);
            imageView.setImageResource(tabHostIconSelect[0]);
        }
        else if(tabId.equals(tabHostTag[1])) {
            ImageView imageView = viewList.get(1).findViewById(R.id.iv_img);
            imageView.setImageResource(tabHostIconSelect[1]);
        }
        else if(tabId.equals(tabHostTag[2])) {
            ImageView imageView = viewList.get(2).findViewById(R.id.iv_img);
            imageView.setImageResource(tabHostIconSelect[2]);
        }
        else{
            ImageView imageView = viewList.get(3).findViewById(R.id.iv_img);
            imageView.setImageResource(tabHostIconSelect[3]);
        }
    }

    //==用于判断原始数据类型
    private View getTabView(String text, int imageID){
        //1.通过布局填充器，根据布局文件创建视图对象
        View view = LayoutInflater.from(this).inflate(R.layout.tabview,null);
        //2.通过findViewById方法，找到相应控件
        TextView textView = view.findViewById(R.id.tv_text);
        ImageView imageView = view.findViewById(R.id.iv_img);
        //3.对相应控件进行设置
        textView.setText(text);
        imageView.setImageResource(imageID);
        //将创建好的选项卡视图控件放入viewList中
        viewList .add(view);
        //4.返回设置好的view
        return view;
    }
    // ViewPager的监听事件
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int i) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return false;
    }

}