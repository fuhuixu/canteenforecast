package cn.edu.hebtu.software.canteen;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderManagerActivity extends AppCompatActivity{

    private ListView listView;
    private MyAdapter myAdapter;
    private List<Map<String,Object>> mapList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_manage);

        listView = findViewById(R.id.lv);
        mapList = getList();
        myAdapter = new MyAdapter(mapList, this, R.layout.activity_manage_content);
        listView.setAdapter(myAdapter);

        //新订单
        ImageView ivNew = findViewById(R.id.iv_new);
        ivNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderManagerActivity.this,NewOrderActivity.class);
                startActivity(intent);
                finish();
            }
        });
        TextView tvNew = findViewById(R.id.tv_new);
        tvNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderManagerActivity.this,NewOrderActivity.class);
                startActivity(intent);
                finish();
            }
        });
        //异常
        ImageView ivError = findViewById(R.id.iv_error);
        ivError.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderManagerActivity.this,ErrorOrderActivity.class);
                startActivity(intent);
                finish();
            }
        });
        TextView tvError = findViewById(R.id.tv_error);
        tvError.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderManagerActivity.this,ErrorOrderActivity.class);
                startActivity(intent);
                finish();
            }
        });
        //催单
        ImageView ivUrge = findViewById(R.id.iv_urge);
        ivUrge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderManagerActivity.this,UrgeActivity.class);
                startActivity(intent);
                finish();
            }
        });
        TextView tvUrge = findViewById(R.id.tv_urge);
        tvUrge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(OrderManagerActivity.this,UrgeActivity.class);
                startActivity(intent);
                finish();
            }
        });
        //取消订单
        ImageView ivCancel = findViewById(R.id.iv_cancel);
        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(OrderManagerActivity.this,"您已取消订单成功！",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                intent.setClass(OrderManagerActivity.this,BackActivity.class);
                startActivity(intent);
            }
        });
        TextView tvCancel = findViewById(R.id.tv_cancel);
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(OrderManagerActivity.this,"您已取消订单成功！",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                intent.setClass(OrderManagerActivity.this,BackActivity.class);
                startActivity(intent);
            }
        });

    }

    //Adapter
    private  class MyAdapter extends BaseAdapter{

        private List<Map<String,Object>> list;
        private Context context;
        private int itemId;

        public MyAdapter(List<Map<String,Object>> list,Context context,int itemId){
            this.list = list;
            this.context = context;
            this.itemId = itemId;
        }
        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(itemId, null);
            TextView name = convertView.findViewById(R.id.tv_order_name);
            TextView count = convertView.findViewById(R.id.tv_order_count);
            TextView price = convertView.findViewById(R.id.tv_order_price);

            name.setText(getList().get(position).get("name").toString());
            count.setText(getList().get(position).get("count").toString());
            price.setText(getList().get(position).get("price").toString());
            return convertView;
        }

    }
    public  List<Map<String, Object>> getList() {
        List<Map<String, Object>> list = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();

        map1.put("name", "三杯鸡");
        map1.put("count","x3");
        map1.put("price","￥27");
        Map<String, Object> map2 = new HashMap<>();
        map2.put("name", "干煸菜花");
        map2.put("count","x1");
        map2.put("price","￥7");
        Map<String, Object> map3 = new HashMap<>();
        map3.put("name", "酸辣土豆丝");
        map3.put("count","x5");
        map3.put("price","￥20");;
        Map<String, Object> map4 = new HashMap<>();
        map4.put("name", "红烧肉");
        map4.put("count","x3");
        map4.put("price","￥30");
        Map<String, Object> map5 = new HashMap<>();
        map5.put("name", "水煮肉片");
        map5.put("count","x4");
        map5.put("price","￥40");
        Map<String, Object> map6 = new HashMap<>();
        map6.put("name", "炸鸡腿");
        map6.put("count","x3");
        map6.put("price","￥35");
        list.add(map1);
        list.add(map2);
        list.add(map3);
        list.add(map4);
        list.add(map5);
        list.add(map6);
        return list;
    }

}

