package cn.edu.hebtu.software.canteen;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BackOrderCalendarShowActivity extends AppCompatActivity {
    private TextView tvReturn;
    private ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_show);

        tvReturn = findViewById(R.id.tv_calendar_show_return);
        listView = findViewById(R.id.lv_ack_calendar_show);
        ListAdapter adapter = new ListAdapter(BackOrderCalendarShowActivity.this,
                R.layout.activity_calendar_show_item,getData());
        listView.setAdapter(adapter);
        tvReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackOrderCalendarShowActivity.this,OrderSelectActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
    public class ListAdapter extends BaseAdapter {
        private Context context;
        private int itemid;
        private List<Map<String,Object>> list;

        public ListAdapter(Context context,int itemid,List<Map<String,Object>> list){
            this.context=context;
            this.itemid=itemid;
            this.list=list;
        }
        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            if(convertView==null){
                LayoutInflater inflater=LayoutInflater.from(context);
                convertView=inflater.inflate(itemid,null);
            }
            TextView name = convertView.findViewById(R.id.tv_back_calendar_show_name);
            TextView price = convertView.findViewById(R.id.tv_back_calendar_show_price);
            TextView date = convertView.findViewById(R.id.tv_back_calendar_show_date);
            name.setText((String)list.get(position).get("name"));
            price.setText((String)list.get(position).get("price"));
            date.setText((String)list.get(position).get("date"));
            return convertView;

        }
    }
    public List<Map<String,Object>> getData(){
        List<Map<String,Object>>list = new ArrayList<>();
        Map<String,Object> map1 = new HashMap<>();
        map1.put("name","张学友");
        map1.put("price","12.5");
        map1.put("date","2019.5.6");
        Map<String,Object> map2 = new HashMap<>();
        map2.put("name","黎明");
        map2.put("price","10");
        map2.put("date","2019.5.6");
        Map<String,Object> map3 = new HashMap<>();
        map3.put("name","郭富城");
        map3.put("price","13");
        map3.put("date","2019.5.6");
        Map<String,Object> map4 = new HashMap<>();
        map4.put("name","刘德华");
        map4.put("price","10");
        map4.put("date","2019.5.6");
        Map<String,Object> map5 = new HashMap<>();
        map5.put("name","梁朝伟");
        map5.put("price","14");
        map5.put("date","2019.5.6");
        Map<String,Object> map6 = new HashMap<>();
        map6.put("name","张国荣");
        map6.put("price","13.2");
        map6.put("date","2019.5.6");
        Map<String,Object> map7 = new HashMap<>();
        map7.put("name","吴彦祖");
        map7.put("price","13.5");
        map7.put("date","2019.5.6");
        Map<String,Object> map8 = new HashMap<>();
        map8.put("name","谢霆锋");
        map8.put("price","14");
        map8.put("date","2019.5.6");
        list.add(map1);
        list.add(map2);
        list.add(map3);
        list.add(map4);
        list.add(map5);
        list.add(map6);
        list.add(map7);
        list.add(map8);
        return list;
    }
}
