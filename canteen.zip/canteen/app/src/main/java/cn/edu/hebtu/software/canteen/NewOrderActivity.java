package cn.edu.hebtu.software.canteen;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NewOrderActivity extends AppCompatActivity {

    private ListView listView;
    private MyAdapter myAdapter;
    private List<Map<String,Object>> mapList;
    private TextView tvRtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_order);

        listView = findViewById(R.id.lv_order);
        mapList = getList();
        myAdapter = new MyAdapter(this, R.layout.activity_new_order_content, mapList);
        listView.setAdapter(myAdapter);

        //返回
        tvRtn = findViewById(R.id.tv_rtn);
        tvRtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(NewOrderActivity.this,OrderManagerActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    //Adapter
    private  class MyAdapter extends BaseAdapter{

        private Context context;
        private int itemId;
        private List<Map<String, Object>> list;
        private LayoutInflater inflater = null;

        public MyAdapter(Context context, int itemId, List<Map<String, Object>> list) {
            this.context = context;
            this.itemId = itemId;
            this.list = list;
            inflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() { return list.size(); }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemId, null);
                TextView name = convertView.findViewById(R.id.tv_order_name);
                TextView count = convertView.findViewById(R.id.tv_order_count);
                TextView price = convertView.findViewById(R.id.tv_order_price);
                Button button = convertView.findViewById(R.id.btn_newOrder);

                name.setText(getList().get(position).get("name").toString());
                count.setText(getList().get(position).get("count").toString());
                price.setText(getList().get(position).get("price").toString());

                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(NewOrderActivity.this,"接单成功",Toast.LENGTH_SHORT)
                                .show();
                    }
                });

            return convertView;
        }

    }
    public  List<Map<String, Object>> getList() {
        List<Map<String, Object>> list = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        //从数据库接受数据
        map1.put("name", "三杯鸡");
        map1.put("count","x3");
        map1.put("price","￥27");
        Map<String, Object> map2 = new HashMap<>();
        map2.put("name", "干煸菜花");
        map2.put("count","x1");
        map2.put("price","￥7");
        Map<String, Object> map3 = new HashMap<>();
        map3.put("name", "酸辣土豆丝");
        map3.put("count","x5");
        map3.put("price","￥20");;
        Map<String, Object> map4 = new HashMap<>();
        map4.put("name", "红烧肉");
        map4.put("count","x3");
        map4.put("price","￥30");
        Map<String, Object> map5 = new HashMap<>();
        map5.put("name", "水煮肉片");
        map5.put("count","x4");
        map5.put("price","￥40");
        Map<String, Object> map6 = new HashMap<>();
        map6.put("name", "炸鸡腿");
        map6.put("count","x3");
        map6.put("price","￥35");
        list.add(map1);
        list.add(map2);
        list.add(map3);
        list.add(map4);
        list.add(map5);
        list.add(map6);
        return list;
    }
}
