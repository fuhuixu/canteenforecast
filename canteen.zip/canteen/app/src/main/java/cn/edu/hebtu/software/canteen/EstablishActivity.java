package cn.edu.hebtu.software.canteen;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EstablishActivity extends AppCompatActivity{
    private MyAdapter myAdapter;
    private ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canteen_establish);

        List<Map<String,Object>> list = new ArrayList<>();
        listView = findViewById(R.id.lv_back_establish);
        myAdapter = new MyAdapter(EstablishActivity.this, R.layout.activity_establish_item,getData());
        listView.setAdapter(myAdapter);

        //返回跳转
        Button btnEstablishReturn = findViewById(R.id.btn_accounestablish_return);
        btnEstablishReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(EstablishActivity.this,BackActivity.class);
                startActivity(intent);
            }
        });
    }
    public class MyAdapter extends BaseAdapter {
        private List<Map<String,Object>> list;
        private Context context;
        private int itemId;

        public MyAdapter(Context context,int itemId,List<Map<String,Object>> list){
            this.context = context;
            this.itemId = itemId;
            this.list = list;
        }
        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Log.e("1","shipeiqi");
            if(convertView == null){
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(itemId,null);
            }
            ImageView image = convertView.findViewById(R.id.iv_establish_img);
            TextView description = convertView.findViewById(R.id.tv_establish);

            Map<String,Object> map = list.get(position);
            image.setImageResource((int)map.get("image"));
            description.setText((String)map.get("description"));
            return convertView;
        }
    }

    public List<Map<String,Object>> getData(){
        List <Map<String,Object>> list = new ArrayList<>();
        Map<String,Object> map2 = new HashMap<>();
        map2.put("image",R.drawable.bc2);
        map2.put("description","餐厅一角");

        Map<String,Object> map3 = new HashMap<>();
        map3.put("image",R.mipmap.bc10);
        map3.put("description","餐厅一角");

        Map<String,Object> map4 = new HashMap<>();
        map4.put("image",R.mipmap.bc3);
        map4.put("description","餐厅一角");

        Map<String,Object> map5 = new HashMap<>();
        map5.put("image",R.mipmap.bc4);
        map5.put("description","餐厅一角");

        Map<String,Object> map6 = new HashMap<>();
        map6.put("image",R.mipmap.bc5);
        map6.put("description","餐厅一角");

        Map<String,Object> map7 = new HashMap<>();
        map7.put("image",R.mipmap.bc6);
        map7.put("description","菜品展示");

        Map<String,Object> map8 = new HashMap<>();
        map8.put("image",R.mipmap.bc9);
        map8.put("description","菜品展示");

        list.add(map2);
        list.add(map3);
        list.add(map4);
        list.add(map5);
        list.add(map6);
        list.add(map7);
        list.add(map8);
        return list;
    }
}
