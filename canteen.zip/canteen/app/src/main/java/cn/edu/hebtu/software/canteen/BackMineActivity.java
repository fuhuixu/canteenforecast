package cn.edu.hebtu.software.canteen;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class BackMineActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_back_mine);

        //返回
        Button btn = findViewById(R.id.back);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackMineActivity.this,BackActivity.class);
                startActivity(intent);
            }
        });
        //退出登录
        TextView exit = findViewById(R.id.exit);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackMineActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });
        //跳转修改密码
        TextView tvPwd = findViewById(R.id.tv_pwd);
        TextView tvPwd1 = findViewById(R.id.tv_pwd1);
        tvPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackMineActivity.this,EditPwdActivity.class);
                startActivity(intent);
            }
        });
        tvPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(BackMineActivity.this,EditPwdActivity.class);
                startActivity(intent);
            }
        });
    }
}
